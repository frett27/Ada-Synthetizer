var structSoundIoDevice =
[
    [ "aim", "structSoundIoDevice.html#ad0bb990b55420890b1b6eb8f1e3b0db0", null ],
    [ "current_format", "structSoundIoDevice.html#acca754332130debf2180f13ec83b5f8c", null ],
    [ "current_layout", "structSoundIoDevice.html#a6f0e2931ff44104fbe9ef8a6d290aa18", null ],
    [ "format_count", "structSoundIoDevice.html#a12a212a89d9187994266ef046705babd", null ],
    [ "formats", "structSoundIoDevice.html#acf6c78f0835ec03f3afefd9e6d29c3bd", null ],
    [ "id", "structSoundIoDevice.html#a7413ecdfdc99f2b89e60fff87c1f8483", null ],
    [ "is_raw", "structSoundIoDevice.html#afb73b9bd13e98a14a187567f508acebe", null ],
    [ "layout_count", "structSoundIoDevice.html#a259a5799492de124be78ff7ba4fbd32b", null ],
    [ "layouts", "structSoundIoDevice.html#a4d82b4c282931e3c819be01fe6c42052", null ],
    [ "name", "structSoundIoDevice.html#a364b77e81883dc151fce31d2793e80f3", null ],
    [ "probe_error", "structSoundIoDevice.html#a129f523c7d43096985c058bc67fe3b6c", null ],
    [ "ref_count", "structSoundIoDevice.html#a0e50e20d4f7947e6aeec048d708c248d", null ],
    [ "sample_rate_count", "structSoundIoDevice.html#a887a751028b4756277b2c625d170adc7", null ],
    [ "sample_rate_current", "structSoundIoDevice.html#a6939f55fa971d912e5e9bd08eafa5932", null ],
    [ "sample_rates", "structSoundIoDevice.html#a54aa08d2848b144faf90c08a727e9dea", null ],
    [ "software_latency_current", "structSoundIoDevice.html#abd9907816714c0a736e74d67e17cdcd7", null ],
    [ "software_latency_max", "structSoundIoDevice.html#a4c03bb16f2b359ada5a4ed646637538f", null ],
    [ "software_latency_min", "structSoundIoDevice.html#a03ccab55899fb21cfe41b0d05bd18358", null ],
    [ "soundio", "structSoundIoDevice.html#a76a1cea550a0bee7e002df70ee61c8de", null ]
];