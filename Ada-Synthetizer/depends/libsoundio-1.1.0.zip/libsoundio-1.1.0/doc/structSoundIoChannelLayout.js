var structSoundIoChannelLayout =
[
    [ "channel_count", "structSoundIoChannelLayout.html#a8812bd6ef1f42b5cab460de9147ac2c7", null ],
    [ "channels", "structSoundIoChannelLayout.html#a50ac9c79316960174cdb8c9ceafe8da5", null ],
    [ "name", "structSoundIoChannelLayout.html#a61e48e5f2355397bf460c610f14f830e", null ]
];