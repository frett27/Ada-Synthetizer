var examples =
[
    [ "backend_disconnect_recover.c", "backend_disconnect_recover_8c-example.html", null ],
    [ "sio_list_devices.c", "sio_list_devices_8c-example.html", null ],
    [ "sio_microphone.c", "sio_microphone_8c-example.html", null ],
    [ "sio_record.c", "sio_record_8c-example.html", null ],
    [ "sio_sine.c", "sio_sine_8c-example.html", null ]
];