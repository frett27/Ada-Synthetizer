var globals_dup =
[
    [ "s", "globals.html", null ]
];