var config_8h =
[
    [ "SOUNDIO_HAVE_ALSA", "config_8h.html#ac0d55a78a7cb204d35114ee0c27d219e", null ],
    [ "SOUNDIO_HAVE_JACK", "config_8h.html#a64d78d43ebcddb692704695731771c38", null ],
    [ "SOUNDIO_HAVE_PULSEAUDIO", "config_8h.html#a374872c9816db78b31d577f1c2b04790", null ],
    [ "SOUNDIO_VERSION_MAJOR", "config_8h.html#a346255eb4399ce69fbe751bb8748e533", null ],
    [ "SOUNDIO_VERSION_MINOR", "config_8h.html#a2a657ede54ca37ce2878806d4e1346b5", null ],
    [ "SOUNDIO_VERSION_PATCH", "config_8h.html#ab385c456d588593b8f723557223fc9cc", null ],
    [ "SOUNDIO_VERSION_STRING", "config_8h.html#a0ec8656d7bd4febb3109470456086da0", null ]
];