var structSoundIoChannelArea =
[
    [ "ptr", "structSoundIoChannelArea.html#a153e9f7fa5412b37cd55331c2d6387e6", null ],
    [ "step", "structSoundIoChannelArea.html#ae63a7441a09315f433662b0113e5b52e", null ]
];