var structSoundIo =
[
    [ "app_name", "structSoundIo.html#a4d7782959728999bd6dcc8c7633a0d8a", null ],
    [ "current_backend", "structSoundIo.html#ac5f9243c5c296f7b073c4fe1831d4d8d", null ],
    [ "emit_rtprio_warning", "structSoundIo.html#a81f4db36631b61ffde57b149698f59f6", null ],
    [ "jack_error_callback", "structSoundIo.html#a504a1420d7244edaabf039b12c846959", null ],
    [ "jack_info_callback", "structSoundIo.html#ac3cdd5837bcabca44804bbd70069866b", null ],
    [ "on_backend_disconnect", "structSoundIo.html#ab4585af46cc289572f2a1d6b6f417fa9", null ],
    [ "on_devices_change", "structSoundIo.html#a1f0689106f1bfcd5cba8aa3695781d1f", null ],
    [ "on_events_signal", "structSoundIo.html#ac9ac4828b342af8458afbdbe4500f862", null ],
    [ "userdata", "structSoundIo.html#abf3f0a91152aec0089ef78295e7e5c92", null ]
];