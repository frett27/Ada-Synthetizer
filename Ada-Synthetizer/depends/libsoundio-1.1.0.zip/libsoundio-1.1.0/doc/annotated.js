var annotated =
[
    [ "SoundIo", "structSoundIo.html", "structSoundIo" ],
    [ "SoundIoChannelArea", "structSoundIoChannelArea.html", "structSoundIoChannelArea" ],
    [ "SoundIoChannelLayout", "structSoundIoChannelLayout.html", "structSoundIoChannelLayout" ],
    [ "SoundIoDevice", "structSoundIoDevice.html", "structSoundIoDevice" ],
    [ "SoundIoInStream", "structSoundIoInStream.html", "structSoundIoInStream" ],
    [ "SoundIoOutStream", "structSoundIoOutStream.html", "structSoundIoOutStream" ],
    [ "SoundIoSampleRateRange", "structSoundIoSampleRateRange.html", "structSoundIoSampleRateRange" ]
];