var structSoundIoSampleRateRange =
[
    [ "max", "structSoundIoSampleRateRange.html#a11293f044d84d68e0f9e61e895e82f43", null ],
    [ "min", "structSoundIoSampleRateRange.html#a6bd9e0eadec07afedb339941caf32259", null ]
];