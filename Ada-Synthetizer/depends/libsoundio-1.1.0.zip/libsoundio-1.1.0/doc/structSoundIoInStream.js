var structSoundIoInStream =
[
    [ "bytes_per_frame", "structSoundIoInStream.html#a85a89a99de54b05975350a7436e443bd", null ],
    [ "bytes_per_sample", "structSoundIoInStream.html#ad0a93d675fe2061e6502880724535f64", null ],
    [ "device", "structSoundIoInStream.html#a8a5c727f8bd0cbf61acfe5cd5307a0f2", null ],
    [ "error_callback", "structSoundIoInStream.html#a3114c2714379ba9e2b972129a82069e0", null ],
    [ "format", "structSoundIoInStream.html#a884ee9d40594e4a07338fe77e616c3ff", null ],
    [ "layout", "structSoundIoInStream.html#a102995358a24f895065a5cfef6538415", null ],
    [ "layout_error", "structSoundIoInStream.html#a8a9eb335cdc4f9dc527076d3b7cc1fae", null ],
    [ "name", "structSoundIoInStream.html#a34d05caa88a0e18cfa9c4f534b097b38", null ],
    [ "non_terminal_hint", "structSoundIoInStream.html#aff49aedaf4f8cb04360dd5f0273e2a5d", null ],
    [ "overflow_callback", "structSoundIoInStream.html#a5fe2403982700d0786aca624aa924325", null ],
    [ "read_callback", "structSoundIoInStream.html#aecda2dbb80f79bee8f906c88fd6c00d9", null ],
    [ "sample_rate", "structSoundIoInStream.html#a08f2e3f2d8818eb8581f78859c85fbd1", null ],
    [ "software_latency", "structSoundIoInStream.html#a39160da93a68220f8cb1d1f10b0e7a3d", null ],
    [ "userdata", "structSoundIoInStream.html#ae6119897a47a4ee252bd971d346d0c1d", null ]
];