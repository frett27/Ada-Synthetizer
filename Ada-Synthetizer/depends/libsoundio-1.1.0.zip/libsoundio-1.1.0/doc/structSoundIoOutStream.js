var structSoundIoOutStream =
[
    [ "bytes_per_frame", "structSoundIoOutStream.html#a799cd8220282eee3d21b6a0511e9533a", null ],
    [ "bytes_per_sample", "structSoundIoOutStream.html#a873db96a2513e4875887c8ff66ff97b2", null ],
    [ "device", "structSoundIoOutStream.html#a2da7fdc9563365897c1dd454e500f7e9", null ],
    [ "error_callback", "structSoundIoOutStream.html#ac111b58fef8bf4d561ba9fa65e5b5fb7", null ],
    [ "format", "structSoundIoOutStream.html#a164722836745394086aefb53f0a0c5c8", null ],
    [ "layout", "structSoundIoOutStream.html#a37cb9fa2bb2693794142f3a52486c839", null ],
    [ "layout_error", "structSoundIoOutStream.html#a1e8831ac68aab9bd3a411a758b096bff", null ],
    [ "name", "structSoundIoOutStream.html#a3e3f869a0af4ef1914a864c93ce8d3c2", null ],
    [ "non_terminal_hint", "structSoundIoOutStream.html#a6da85b1b8d2ef47b73774fa09fb12565", null ],
    [ "sample_rate", "structSoundIoOutStream.html#a7c2d76e17c5031a589879522b7a823d1", null ],
    [ "software_latency", "structSoundIoOutStream.html#a20aac1422d3cc64b679616bb8447f06d", null ],
    [ "underflow_callback", "structSoundIoOutStream.html#ae00fe63a46a0fe106430692f75337e34", null ],
    [ "userdata", "structSoundIoOutStream.html#a14549e062b980bf32254718403c55ca2", null ],
    [ "write_callback", "structSoundIoOutStream.html#a9b6634417ccaec9b5c4376728efb186d", null ]
];